#########################################################################################
#                                                                                       #
# ©2015 Microchip Technology Inc.and its subsidiaries.You may use this software and any #
# derivatives exclusively with Microchip products.                                      #
#                                                                                       #
# THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".NO WARRANTIES, WHETHER EXPRESS,        #
# IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF     #
# NON - INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS     #
# INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR          #
# USE IN ANY APPLICATION.                                                               #
#                                                                                       #
# IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL  #
# OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED         #
# TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE            #
# POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.TO THE FULLEST EXTENT ALLOWED BY           #
# LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE    #
# WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO            #
# MICROCHIP FOR THIS SOFTWARE.                                                          #
#                                                                                       #
# MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE          #
# TERMS.                                                                                #
#                                                                                       #
#########################################################################################

# MCP2210 demo using unmanaged DLL from python.

# import the mcp2210 unmanaged DLL
from ctypes import *
mcp2210 = windll.LoadLibrary("mcp2210_dll_um_x64.dll")

Mcp2210_GetLibraryVersion       = mcp2210.Mcp2210_GetLibraryVersion
Mcp2210_GetLastError            = mcp2210.Mcp2210_GetLastError
Mcp2210_GetConnectedDevCount    = mcp2210.Mcp2210_GetConnectedDevCount
Mcp2210_OpenByIndex             = mcp2210.Mcp2210_OpenByIndex
Mcp2210_Close                   = mcp2210.Mcp2210_Close
Mcp2210_GetManufacturerString   = mcp2210.Mcp2210_GetManufacturerString
Mcp2210_GetProductString        = mcp2210.Mcp2210_GetProductString
Mcp2210_GetSerialNumber         = mcp2210.Mcp2210_GetSerialNumber

Mcp2210_OpenByIndex.restype = c_void_p

#VID and PID of the MCP2210 devices
vid = c_ushort(0x4d8)
pid = c_ushort(0xde)

#error codes dictionary
errors_dict = {    0:'E_SUCCESS',                             -1:'E_ERR_UNKOWN_ERROR',            -2:'E_ERR_INVALID_PARAMETER',\
                 -10:'E_ERR_NULL',                           -20:'E_ERR_MALLOC',                 -30:'E_ERR_INVALID_HANDLE_VALUE',\
                -100:'E_ERR_FIND_DEV',                      -101:'E_ERR_NO_SUCH_INDEX',         -103:'E_ERR_DEVICE_NOT_FOUND',\
                -104:'E_ERR_INTERNAL_BUFFER_TOO_SMALL',     -105:'E_ERR_OPEN_DEVICE_ERROR',     -106:'E_ERR_CONNECTION_ALREADY_OPENED',\
                -107:'E_ERR_CLOSE_FAILED',                  -108:'E_ERR_NO_SUCH_SERIALNR',      -110:'E_ERR_HID_RW_TIMEOUT',\
                -111:'E_ERR_HID_RW_FILEIO',                 -200:'E_ERR_CMD_FAILED',            -201:'E_ERR_CMD_ECHO',\
                -202:'E_ERR_SUBCMD_ECHO',                   -203:'E_ERR_SPI_CFG_ABORT',         -204:'E_ERR_SPI_EXTERN_MASTER',\
                -205:'E_ERR_SPI_TIMEOUT',                   -206:'E_ERR_SPI_RX_INCOMPLETE',     -207:'E_ERR_SPI_XFER_ONGOING',\
                -300:'E_ERR_BLOCKED_ACCESS',                -301:'E_ERR_EEPROM_WRITE_FAIL',     -350:'E_ERR_NVRAM_LOCKED',\
                -351:'E_ERR_WRONG_PASSWD',                  -352:'E_ERR_ACCESS_DENIED',         -353:'E_ERR_NVRAM_PROTECTED',\
                -354:'E_ERR_PASSWD_CHANGE',                 -400:'E_ERR_STRING_DESCRIPTOR',     -401:'E_ERR_STRING_TOO_LARGE'    }

# print the welcome message and DLL version
version = create_unicode_buffer(32)   #version buffer size must be 64bytes (32 unicode characters)
  
ret_code = Mcp2210_GetLibraryVersion(version)
if ret_code == -10:
    print("Ooops...null pointer detected!!. Exiting...")
    exit()
else:
    print ("List MCP2210 devices using MCP2210 unmanaged DLL version ", version.value)


# detect the number of mcp2210 connected devices
print ("Counting the MCP2210 devices (with VID:0x%4.4X, PID:0x%4.4X):" % (vid.value, pid.value))
ret_code = Mcp2210_GetConnectedDevCount(vid, pid)
if ret_code < 0:
    print("Ooops...error code returned: ", errors_dict.get(ret_code, ret_code), ". Exiting...")
    exit()
else:
    print("Detected: ", ret_code)

# if no device detected, exit the application
if ret_code == 0:
    print("No device was detected...Bye!")
    exit()

dev_count = ret_code

# For each device found print the specific info
for idx in range(0, dev_count):
    print("\nMCP2210 #%d:" % idx)
    # Open the device with index #idx
    index = c_uint32(idx)
    path = create_unicode_buffer(1)     #fake path buffer - first "open" call will return the needed size
    pathsize = c_ulong(1)              #insufficient size provisioned in order to obtain the needed size

    handle0 = c_void_p(Mcp2210_OpenByIndex(vid, pid, index, path, byref(pathsize)));
    ret_code = Mcp2210_GetLastError()
    if ret_code != -3:  #E_ERR_BUFFER_TOO_SMALL
        print("\nUnexpected error code returned: ", errors_dict.get(ret_code, ret_code), ". Exiting...")
        exit()

    del path
    path = create_unicode_buffer(int(pathsize.value/sizeof(c_wchar)))
    handle0 = c_void_p(Mcp2210_OpenByIndex(vid, pid, index, path, byref(pathsize)));
    ret_code = Mcp2210_GetLastError()
    if ret_code != 0: #E_SUCCESS
        print("\nUnexpected error code returned: ", errors_dict.get(ret_code, ret_code), ". Exiting...")
        exit()
    else:
        print ("\t-the path is: ", path.value)

    # print the manufacturer descriptor
    manufacturer = create_unicode_buffer(30)    #descriptor length is max 30 unicode characters including NULL terminator
    ret_code = Mcp2210_GetManufacturerString(handle0, manufacturer)
    if ret_code != 0: #E_SUCCESS
        print("Unexpected error code returned: ", errors_dict.get(ret_code, ret_code))
    else:
        print ("\t-the manufacturer descriptor is: ", manufacturer.value)

    # print the product descriptor
    product = create_unicode_buffer(30)    #descriptor length is max 30 unicode characters including NULL terminator
    ret_code = Mcp2210_GetProductString(handle0, product)
    if ret_code != 0: #E_SUCCESS
        print("Unexpected error code returned: ", errors_dict.get(ret_code, ret_code))
    else:
        print ("\t-the product descriptor is: ", product.value)

    # print the serial number
    productSN = create_unicode_buffer(30)    #descriptor length is max 30 unicode characters including NULL terminator
    ret_code = Mcp2210_GetSerialNumber(handle0, productSN)
    if ret_code != 0: #E_SUCCESS
        print("Unexpected error code returned: ", errors_dict.get(ret_code, ret_code))
    else:
        print ("\t-the product Serial Number is: ", productSN.value)

    # close the MCP2210 device with index #idx
    ret_code = Mcp2210_Close(handle0)
    if ret_code != 0: #E_SUCCESS
        print("Unexpected error code returned: ", errors_dict.get(ret_code, ret_code), ". Exiting...")
        exit()



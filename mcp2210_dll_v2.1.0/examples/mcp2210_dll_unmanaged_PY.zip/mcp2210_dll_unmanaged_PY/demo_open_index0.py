#########################################################################################
#                                                                                       #
# ©2015 Microchip Technology Inc.and its subsidiaries.You may use this software and any #
# derivatives exclusively with Microchip products.                                      #
#                                                                                       #
# THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".NO WARRANTIES, WHETHER EXPRESS,        #
# IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF     #
# NON - INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS     #
# INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR          #
# USE IN ANY APPLICATION.                                                               #
#                                                                                       #
# IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL  #
# OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED         #
# TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE            #
# POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.TO THE FULLEST EXTENT ALLOWED BY           #
# LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE    #
# WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO            #
# MICROCHIP FOR THIS SOFTWARE.                                                          #
#                                                                                       #
# MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE          #
# TERMS.                                                                                #
#                                                                                       #
#########################################################################################

print ("MCP2210 demo using unmanaged DLL from python.")
print ("Please connect at least one MCP2210 device on USB.")

# import the mcp2210 unmanaged DLL
from ctypes import *
mcp2210 = windll.LoadLibrary("mcp2210_dll_um_x64.dll")

Mcp2210_GetLibraryVersion       = mcp2210.Mcp2210_GetLibraryVersion
Mcp2210_GetLastError            = mcp2210.Mcp2210_GetLastError
Mcp2210_GetConnectedDevCount    = mcp2210.Mcp2210_GetConnectedDevCount
Mcp2210_OpenByIndex             = mcp2210.Mcp2210_OpenByIndex
Mcp2210_Close                   = mcp2210.Mcp2210_Close
Mcp2210_GetManufacturerString   = mcp2210.Mcp2210_GetManufacturerString

Mcp2210_OpenByIndex.restype = c_void_p

#VID and PID of the MCP2210 devices
vid = c_ushort(0x4d8)
pid = c_ushort(0xde)

#error codes dictionary
errors_dict = {    0:'E_SUCCESS',                             -1:'E_ERR_UNKOWN_ERROR',            -2:'E_ERR_INVALID_PARAMETER',\
                 -10:'E_ERR_NULL',                           -20:'E_ERR_MALLOC',                 -30:'E_ERR_INVALID_HANDLE_VALUE',\
                -100:'E_ERR_FIND_DEV',                      -101:'E_ERR_NO_SUCH_INDEX',         -103:'E_ERR_DEVICE_NOT_FOUND',\
                -104:'E_ERR_INTERNAL_BUFFER_TOO_SMALL',     -105:'E_ERR_OPEN_DEVICE_ERROR',     -106:'E_ERR_CONNECTION_ALREADY_OPENED',\
                -107:'E_ERR_CLOSE_FAILED',                  -108:'E_ERR_NO_SUCH_SERIALNR',      -110:'E_ERR_HID_RW_TIMEOUT',\
                -111:'E_ERR_HID_RW_FILEIO',                 -200:'E_ERR_CMD_FAILED',            -201:'E_ERR_CMD_ECHO',\
                -202:'E_ERR_SUBCMD_ECHO',                   -203:'E_ERR_SPI_CFG_ABORT',         -204:'E_ERR_SPI_EXTERN_MASTER',\
                -205:'E_ERR_SPI_TIMEOUT',                   -206:'E_ERR_SPI_RX_INCOMPLETE',     -207:'E_ERR_SPI_XFER_ONGOING',\
                -300:'E_ERR_BLOCKED_ACCESS',                -301:'E_ERR_EEPROM_WRITE_FAIL',     -350:'E_ERR_NVRAM_LOCKED',\
                -351:'E_ERR_WRONG_PASSWD',                  -352:'E_ERR_ACCESS_DENIED',         -353:'E_ERR_NVRAM_PROTECTED',\
                -354:'E_ERR_PASSWD_CHANGE',                 -400:'E_ERR_STRING_DESCRIPTOR',     -401:'E_ERR_STRING_TOO_LARGE'    }


# print the DLL version
print ("\nPrint the DLL version - use of Mcp2210_GetLibraryVersion():")
version = create_unicode_buffer(u"Hi!",32)   #version buffer size must be 64bytes (32 unicode characters)
  
print ("version buffer value before the API call:", version.value)
ret_code = Mcp2210_GetLibraryVersion(version)
if ret_code == -10:
    print("Ooops...null pointer detected!!. Exiting...")
    exit()
else:
    print ("DLL version value:", version.value)
    print ("DLL version string size (bytes):", ret_code)


# print the number of mcp2210 connected devices
print ("\nPrint the number of MPC2210 devices - use of Mcp2210_GetConnectedDevCount():")
print ("looking for MCP2210 devices - VID:0x%4.4X, PID:0x%4.4X" % (vid.value, pid.value))
ret_code = Mcp2210_GetConnectedDevCount(vid, pid)
if ret_code < 0:
    print("Ooops...error code returned: ", errors_dict.get(ret_code, ret_code),". Exiting...")
    exit()
else:
    print("Number of MCP2210 devices detected: ", ret_code)

# if no device detected, exit the application
if ret_code == 0:
    print("No device was detected...Bye!")
    exit()


# Open the device with index #0 and print the windows path
print ("\nOpen the device with index 0 and print the windows path: - use of Mcp2210_OpenByIndex()")
index0 = c_uint32(0)
path0 = create_unicode_buffer(1)    #fake path0 buffer - first "open" call will return the needed size
pathsize0 = c_ulong(1)              #insufficient size provisioned in order to obtain the needed size

handle0 = c_void_p(Mcp2210_OpenByIndex(vid, pid, index0, path0, byref(pathsize0)));
ret_code = Mcp2210_GetLastError()
if ret_code != -3:  #E_ERR_BUFFER_TOO_SMALL
    print("Unexpected error code returned: ", errors_dict.get(ret_code, ret_code), ". Exiting...")
    exit()
else:
    print ("MCP2210 #0 required pathsize: ", pathsize0.value)

del path0
path0 = create_unicode_buffer(int(pathsize0.value/sizeof(c_wchar)))
handle0 = c_void_p(Mcp2210_OpenByIndex(vid, pid, index0, path0, byref(pathsize0)));
ret_code = Mcp2210_GetLastError()
if ret_code != 0: #E_SUCCESS
    print("Unexpected error code returned: ", errors_dict.get(ret_code, ret_code), ". Exiting...")
    exit()
else:
    print ("MCP2210 #0 opened, path is: ", path0.value)
    print ("handle0 is: 0x%x" % (handle0.value))

# print the manufacturer descriptor of the MCP2210 device #0
print ("\nPrint manufacturer descriptor of the MCP2210 device #0 - use of Mcp2210_GetManufacturerString():")
manufacturer = create_unicode_buffer(30)    #descriptor length is max 30 unicode characters including NULL terminator
ret_code = Mcp2210_GetManufacturerString(handle0, manufacturer)
if ret_code != 0: #E_SUCCESS
    print("Unexpected error code returned: ", errors_dict.get(ret_code, ret_code))
else:
    print ("MCP2210 #0 manufacturer descriptor is: ", manufacturer.value)


# close the MCP2210 device #0
print("\nClose the MCP2210 device #0 - use of Mcp2210_Close():")
ret_code = Mcp2210_Close(handle0)
if ret_code != 0: #E_SUCCESS
    print("Unexpected error code returned: ", errors_dict.get(ret_code, ret_code), ". Exiting...")
    exit()
else:
    print ("Mcp2210_Close() ret_code:", errors_dict.get(ret_code, ret_code))
    print ("handle0: 0x%x" % (handle0.value))

#try a second close attempt on the same handle - should give -30 error code
ret_code = Mcp2210_Close(handle0)
if ret_code != -30: #E_ERR_INVALID_HANDLE_VALUE
    print("Unexpected error code returned: ", errors_dict.get(ret_code, ret_code))
else:
    print ("2nd attempt Mcp2210_Close() ret_code: ", errors_dict.get(ret_code, ret_code))
print ("handle0: 0x%x" % (handle0.value))




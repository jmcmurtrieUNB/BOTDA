﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace mcp2210_dll_unmanaged_test
{
    class Program
    {
        const string DllPath = ".\\mcp2210_dll_um_x86.dll";


        /* API for getting access to the USB device */
        [DllImport(DllPath, EntryPoint = "Mcp2210_GetLibraryVersion", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_GetLibraryVersion(StringBuilder version);
        [DllImport(DllPath, EntryPoint = "Mcp2210_GetLastError", CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_GetLastError();
        [DllImport(DllPath, EntryPoint = "Mcp2210_GetConnectedDevCount", CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_GetConnectedDevCount(ushort vid, ushort pid);
        [DllImport(DllPath, EntryPoint = "Mcp2210_OpenByIndex", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern IntPtr Mcp2210_OpenByIndex(ushort vid, ushort pid, uint index, StringBuilder devPath, ref ulong devPathsize);
        [DllImport(DllPath, EntryPoint = "Mcp2210_OpenBySN", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern IntPtr Mcp2210_OpenBySN(ushort vid, ushort pid, String serialNo, StringBuilder devPath, ref ulong devPathsize);
        [DllImport(DllPath, EntryPoint = "Mcp2210_Close", CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_Close(IntPtr handle);
        [DllImport(DllPath, EntryPoint = "Mcp2210_Reset", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_Reset(IntPtr handle);

        /* USB settings */
        [DllImport(DllPath, EntryPoint = "Mcp2210_GetUsbKeyParams", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_GetUsbKeyParams(IntPtr handle, ref ushort pvid, ref ushort ppid,
                                                         ref byte ppwrSrc, ref byte prmtWkup, ref ushort pcurrentLd);
        [DllImport(DllPath, EntryPoint = "Mcp2210_SetUsbKeyParams", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_SetUsbKeyParams(IntPtr handle, ushort vid, ushort pid,
                                                         byte pwrSrc, byte rmtWkup, ushort currentLd);
        [DllImport(DllPath, EntryPoint = "Mcp2210_GetManufacturerString", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_GetManufacturerString(IntPtr handle, StringBuilder manufacturerStr);
        [DllImport(DllPath, EntryPoint = "Mcp2210_SetManufacturerString", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_SetManufacturerString(IntPtr handle, String manufacturerStr);
        [DllImport(DllPath, EntryPoint = "Mcp2210_GetProductString", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_GetProductString(IntPtr handle, StringBuilder productStr);
        [DllImport(DllPath, EntryPoint = "Mcp2210_SetProductString", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_SetProductString(IntPtr handle, String productStr);
        [DllImport(DllPath, EntryPoint = "Mcp2210_GetSerialNumber", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_GetSerialNumber(IntPtr handle, StringBuilder serialStr);

        /* API to access GPIO settings and values */
        [DllImport(DllPath, EntryPoint = "Mcp2210_GetGpioPinDir", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_GetGpioPinDir(IntPtr handle, ref uint pgpioDir);
        [DllImport(DllPath, EntryPoint = "Mcp2210_SetGpioPinDir", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_SetGpioPinDir(IntPtr handle, uint gpioSetDir);
        [DllImport(DllPath, EntryPoint = "Mcp2210_GetGpioPinVal", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_GetGpioPinVal(IntPtr handle, ref uint pgpioPinVal);
        [DllImport(DllPath, EntryPoint = "Mcp2210_SetGpioPinVal", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_SetGpioPinVal(IntPtr handle, uint gpioSetVal, ref uint pgpioPinVal);
        [DllImport(DllPath, EntryPoint = "Mcp2210_GetGpioConfig", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_GetGpioConfig(IntPtr handle, byte cfgSelector, byte[] pGpioPinDes, ref uint pdfltGpioOutput,
                                                        ref uint pdfltGpioDir, ref byte prmtWkupEn, ref byte pintPinMd, ref byte pspiBusRelEn);
        [DllImport(DllPath, EntryPoint = "Mcp2210_SetGpioConfig", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_SetGpioConfig(IntPtr handle, byte cfgSelector, byte[] pGpioPinDes, uint dfltGpioOutput,
                                                        uint dfltGpioDir, byte rmtWkupEn, byte intPinMd, byte spiBusRelEn);
        [DllImport(DllPath, EntryPoint = "Mcp2210_GetInterruptCount", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_GetInterruptCount(IntPtr handle, ref uint pintCnt, byte reset);

        /* API to control SPI transfer */
        [DllImport(DllPath, EntryPoint = "Mcp2210_GetSpiConfig", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_GetSpiConfig(IntPtr handle, byte cfgSelector, ref uint pbaudRate, ref uint pidleCsVal,
                                                        ref uint pactiveCsVal, ref uint pcsToDataDly, ref uint pdataToCsDly,
                                                        ref uint pdataToDataDly, ref uint ptxferSize, ref byte pspiMd);
        [DllImport(DllPath, EntryPoint = "Mcp2210_SetSpiConfig", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_SetSpiConfig(IntPtr handle, byte cfgSelector, ref uint pbaudRate, ref uint pidleCsVal,
                                                        ref uint pactiveCsVal, ref uint pcsToDataDly, ref uint pdataToCsDly,
                                                        ref uint pdataToDataDly, ref uint ptxferSize, ref byte pspiMd);
        [DllImport(DllPath, EntryPoint = "Mcp2210_xferSpiData", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_xferSpiData(IntPtr handle, byte[] pdataTx, byte[] pdataRx,
                                                        ref uint pbaudRate, ref uint ptxferSize, uint csmask);
        [DllImport(DllPath, EntryPoint = "Mcp2210_xferSpiDataEx", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_xferSpiDataEx(IntPtr handle, byte[] pdataTx, byte[] pdataRx,
                                                        ref uint pbaudRate, ref uint ptxferSize, uint csmask,
                                                        ref uint pidleCsVal, ref uint pactiveCsVal, ref uint pCsToDataDly,
                                                        ref uint pdataToCsDly, ref uint pdataToDataDly, ref byte pspiMd);
        [DllImport(DllPath, EntryPoint = "Mcp2210_CancelSpiTxfer", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_CancelSpiTxfer(IntPtr handle, ref byte pspiExtReqStat, ref byte pspiOwner);
        [DllImport(DllPath, EntryPoint = "Mcp2210_RequestSpiBusRel", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_RequestSpiBusRel(IntPtr handle, byte ackPinVal);
        [DllImport(DllPath, EntryPoint = "Mcp2210_GetSpiStatus", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_GetSpiStatus(IntPtr handle, ref byte pspiExtReqStat, ref byte pspiOwner, ref byte pspiTxferStat);

        /* EEPROM read/write API */
        [DllImport(DllPath, EntryPoint = "Mcp2210_ReadEEProm", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_ReadEEProm(IntPtr handle, byte address, ref byte pcontent);
        [DllImport(DllPath, EntryPoint = "Mcp2210_WriteEEProm", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_WriteEEProm(IntPtr handle, byte address, byte content);

        /* Access control API */
        [DllImport(DllPath, EntryPoint = "Mcp2210_GetAccessCtrlStatus", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_GetAccessCtrlStatus(IntPtr handle, ref byte pAccessCtrl, ref byte pPasswdAttemptCnt, ref byte pPasswdAccepted);
        [DllImport(DllPath, EntryPoint = "Mcp2210_EnterPassword", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_EnterPassword(IntPtr handle, String passwd);
        [DllImport(DllPath, EntryPoint = "Mcp2210_SetAccessControl", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_SetAccessControl(IntPtr handle, byte accessConfig, String currentPasswd, String newPasswd);
        [DllImport(DllPath, EntryPoint = "Mcp2210_SetPermanentLock", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern int Mcp2210_SetPermanentLock(IntPtr handle);

        /**** Constants ****/
        public const ushort DEFAULT_VID = 0x4d8;
        public const ushort DEFAULT_PID = 0xde;

        /**** Error codes ****/
        public const int E_SUCCESS = 0;
        public const int E_ERR_INVALID_PARAMETER = -2;
        public const int E_ERR_BUFFER_TOO_SMALL = -3;
        public const int E_ERR_NULL = -10;
        public const int E_ERR_INVALID_HANDLE_VALUE = -30;
        public const int E_ERR_NO_SUCH_INDEX = -101;
        public const int E_ERR_CONNECTION_ALREADY_OPENED = -106;
        public const int E_ERR_CLOSE_FAILED = -107;
        public const int E_ERR_NO_SUCH_SERIALNR = -108;
        public const int E_ERR_HID_RW_FILEIO = -111;

        public const int E_ERR_SPI_EXTERN_MASTER = -204;
        public const int E_ERR_SPI_TIMEOUT = -205;
        public const int E_ERR_SPI_XFER_ONGOING = -207;

        public const int E_ERR_BLOCKED_ACCESS = -300;
        public const int E_ERR_NVRAM_LOCKED = -350;
        public const int E_ERR_WRONG_PASSWD = -351;
        public const int E_ERR_ACCESS_DENIED = -352;
        public const int E_ERR_NVRAM_PROTECTED = -353;
        public const int E_ERR_PASSWD_CHANGE = -354;

        public const int E_ERR_STRING_TOO_LARGE = -401;


        static int Main(string[] args)
        {


            int devCount = Mcp2210_GetConnectedDevCount(DEFAULT_VID, DEFAULT_PID);
            Console.WriteLine(devCount + " devices found");
            if (devCount > 0)
            {
                StringBuilder path = new StringBuilder();
                IntPtr deviceHandle = new IntPtr();
                ulong pathSize = 0;
                int res;

                deviceHandle = Mcp2210_OpenByIndex(DEFAULT_VID, DEFAULT_PID, 0, path, ref pathSize); //try to open the first device
                res = Mcp2210_GetLastError();
                if (res != E_SUCCESS)
                {
                    Console.WriteLine("Failed to open connection");
                    return -1;
                }


                // set the SPI xfer params for I/O expander
                uint pbaudRate2 = 1000000;
                uint pidleCsVal2 = 0x1ff;
                uint pactiveCsVal2 = 0x1ee; // GP4 and GP0 set as active low CS
                uint pcsToDataDly2 = 0;
                uint pdataToDataDly2 = 0;
                uint pdataToCsDly2 = 0;
                uint ptxferSize2 = 4;     // I/O expander xfer size set to 4
                byte pspiMd2 = 0;
                uint csmask4 = 0x10;  // set GP4 as CS

                byte[] txData = new byte[4], rxData = new byte[4];
                // set the expander config params
                txData[0] = 0x40;
                txData[1] = 0x0A;
                txData[2] = 0xff;
                txData[3] = 0x00;
                // send the data
                // use the extended SPI xfer API first time in order to set all the parameters
                // the subsequent xfers with the same device may use the simple API in order to save CPU cycles
                res = Mcp2210_xferSpiDataEx(deviceHandle, txData, rxData, ref pbaudRate2, ref ptxferSize2, csmask4, ref pidleCsVal2, ref pactiveCsVal2, ref pcsToDataDly2,
                    ref pdataToCsDly2, ref pdataToDataDly2, ref pspiMd2);
                if (res != E_SUCCESS)
                {
                    Mcp2210_Close(deviceHandle);
                    Console.WriteLine(" Transfer error: " + res);
                    return res;
                }

                ptxferSize2 = 3;          // set the txfer size to 3 -> don't write to mcp23s08 IODIR again
                uint csmask_nochange = 0x10000000;   // preserve the CS selection and skip the GP8CE fix -> data xfer optimization
                for (byte i = 0; i < 255; i++)
                {
                    txData[2] = i;
                    // we don't need to change all SPI params so we can start using the faster xfer API
                    res = Mcp2210_xferSpiData(deviceHandle, txData, rxData, ref pbaudRate2, ref ptxferSize2, csmask_nochange);
                    if (res != E_SUCCESS)
                    {
                        Mcp2210_Close(deviceHandle);
                        return res;
                    }
                }

                // turn off the leds -> set the mcp23s08 iodir to 0xFF;
                txData[0] = 0x40;
                txData[1] = 0x00;
                txData[2] = 0xFF;
                res = Mcp2210_xferSpiData(deviceHandle, txData, rxData, ref pbaudRate2, ref ptxferSize2, csmask_nochange);
                if (res != E_SUCCESS)
                {
                    Mcp2210_Close(deviceHandle);
                    return res;
                }


                Mcp2210_Close(deviceHandle);

            }


            return 0;

        }

    }   // Program class
}
